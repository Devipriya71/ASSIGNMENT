package com.cts.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Serviceimplements implements Interfaceservice {
	@Autowired
	private Interfacedao dao;//entity mgr factory
	
	@Override
	public List<Person> getAllPersons() {
		return dao.findAll();				
	}
	@Override
	public Optional<Person> getPersonById(int id) {
		
		return dao.findById(id);
	}
	@Override
	public Person getPersonByName(String name) {
		
			return dao.findByPersonName(name);
	}
	@Override
	public Person findUsingNameAddr(String name,String addr){
		return dao.findUsingNameAddr(name,addr);
	}
	@Override
	public Person delete(int id){
		return dao.delete(id);
	}

}
