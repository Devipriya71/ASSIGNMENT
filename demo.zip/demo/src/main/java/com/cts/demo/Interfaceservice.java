package com.cts.demo;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cts.demo.Person;

public interface Interfaceservice {
	 List<Person> getAllPersons();
	 public Optional<Person> getPersonById(int id);
		public Person getPersonByName(String name) ;
		public Person findUsingNameAddr(String name,String addr);
		public Person delete(int id);
	

}
