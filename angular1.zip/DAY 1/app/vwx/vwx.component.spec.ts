import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VwxComponent } from './vwx.component';

describe('VwxComponent', () => {
  let component: VwxComponent;
  let fixture: ComponentFixture<VwxComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VwxComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VwxComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
