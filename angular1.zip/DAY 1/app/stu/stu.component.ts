import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stu',
  template: '<p>stu works! hello</p>', // inline component
  styleUrls: ['./stu.component.css']
})
export class StuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
